#include "LCD.h"
#include "RISC.h"
#include <stdio.h>
#include <stdio.h>
#include <math.h>
#define F_CPU 16000000


int out = 0;
void delay_us(int d)
{
	volatile int n = d*F_CPU/10000000;
	for(int i = 0; i < n; i++)
	{

	}
}
void delay_ms(int d)
{
	volatile int n = d*F_CPU/10000;
	for(int i = 0; i < n; i++)
	{

	}
}

void lcd_data_write(unsigned char data)
{
	out = 0;
	out |= data;
	out |= (1<<rs);
	out |= (1<<en);
	*gpio_addr = out;
	//delay_us(1);
	delay_ms(1000);
	out &= ~(1<<en);
	*gpio_addr = out;
	//delay_us(100);
	delay_ms(1000);
}
void lcd_cmd_write(unsigned char data)
{
	out = 0;
	out |= data;
	out |= (1<<en);
	*gpio_addr = out;
	//delay_us(1);
	delay_ms(1000);
	out &= ~(1<<en);
	*gpio_addr = out;
	//delay_us(100);
	delay_ms(1000);
	
}

void lcd(int Rs, int En, int d0, int d1, int d2, int d3, int d4, int d5, int d6, int d7)
{
	rs = Rs;
	en = En;
	D0 = d0;
	D1 = d1;
	D2 = d2;
	D3 = d3;
	D4 = d4;
	D5 = d5;
	D6 = d6;
	D7 = d7;
}

void print(char *data)
{
	int x = 0;
	while (data[x] != 0)
		{
			lcd_data_write(data[x]);
			x++;
		}
}


void init()
{
	out = 0;
	//delay_ms(2);	
	delay_ms(1000);
	lcd_cmd_write(0x38);
	lcd_cmd_write(0x0C);
	lcd_cmd_write(0x01);
	//delay_ms(2);
	delay_ms(1000);
	lcd_cmd_write(0x06);
}
void setCursor(unsigned char x, unsigned char y)
{
	unsigned char data = 0;
	if(y)
		data = 0xc0;
	else
		data = 0x80;
	data = data + x;
	
	lcd_cmd_write(data);
	//delay_us(100);
	delay_ms(1000);
}
void clear()
{
	lcd_cmd_write(0x01); 
	lcd_cmd_write(0x02);
}

void int2array(int d, char* p, int len)
{
	for(int i = 0; i < 10; i++)
		p[i] = 0;

	if(d==0)
		p[0] = 48;
	else{
		/* count number of digits */
		int c = 0; /* digit position */
		int z = 0;
		int n = d;

		while (n != 0)
		{
			n /= 10;
			z++;
		}
		n = d;
		/* extract each digit */
		while (n != 0)
		{
			p[z-c-1] = 48 + n % 10;
			n /= 10;
			c++;
		}
	}

}

int main(void)
{

	int seconds = 0;
	char snum[10];
	lcd(9,8,7,6,5,4,3,2,1,0); //rs,en,d0,d1,d2,d3,d4,d5,d6,d7
	char d1[] = "NESCOM";
	init();
	setCursor(0,0);//C,R
	print(d1);
	while(1){		
		
		int2array(seconds, snum, 10);
		setCursor(0,1);//C,R
		print(snum);
		seconds += 1;
		if(seconds > 59)
			seconds  = 0;
		delay_ms(200);
	}
	
}