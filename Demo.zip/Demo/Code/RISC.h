#ifndef RISC_H
#define RISC_H

volatile int *gpio_addr = (int*)0xc00;
#endif
